define(["jquery", "./common.js", "./cordova.service.js", "./mljdbproc.js", "./mljDate.js", "./mljWalkConstants.js", "./mljObjectModel.js", "./synchronisation.js", "./clientService.js", "./donation.js"], function($, commonModule, cordovaModule, mljdbproc, mljDate, mljdbConstantModule, mljObjectModel, synchronisation, clientService, donationModule) {
    var misfitHandler = null;
    var fitnessSourceModule = {
        sso: null,
        sourceInterval : null,
        invocationData: {},
		PrevDateSummaryStep:0,
        misfit : require('node-misfit'),
        initialize: function() {
            console.time('Fitnessinitialize');
                //cordovaModule.isLocationEnabled();
            if(device.platform != "iOS")
            {
                         
                cordova.plugins.backgroundMode.disable();
                navigator.geolocation.clearWatch(window.locationWatchId);

            }
            else
            {               
                cordova.plugins.backgroundMode.disable();
                navigator.geolocation.clearWatch(window.locationWatchId);
            }       
            fitnessSourceModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            //fitnessSourceModule.sso.source = "misfit";    // TODO: hardcoded to googlefit for this build, has to be changed.
            if(fitnessSourceModule.sso.goofitEnabled == true)
            {
                //synchronisation.updateStepCountinDashboard();
                $("#loading-indicator").hide();                
                fitnessSourceModule.syncStepwithDB();
                //clearInterval(commonModule.storage.getItem("dashboardSyncInterval"));
                //clearInterval(commonModule.storage.getItem("fitnessSetInterval"));
                //var dashboardSyncInterval = setInterval(fitnessSourceModule.syncStepwithDB, getSourceInterval);
                //commonModule.storage.setItem("dashboardSyncInterval",dashboardSyncInterval);
            }
			
        	switch (fitnessSourceModule.sso.source) {
                case stepSource[0]://googlefit
                if (fitnessSourceModule.sso.misfitLastHourSteps !== undefined) commonModule.updateSSO({misfitLastHourSteps : 0});
                if (fitnessSourceModule.sso.fitbitLastHourSteps !== undefined) commonModule.updateSSO({fitbitLastHourSteps : 0});
                if(fitnessSourceModule.sso.goofitEnabled != true)
                {
                    navigator.health.isAvailable(function(){
                     cordovaModule.requestAuthorization(function(data){
                        if(device.platform == "iOS"){data="OK"}
                        if(data === "OK"){
                            console.log("googlefit enabled");
                            commonModule.updateSSO({goofitEnabled: true});                            
                            mljDate.getMLJIsToday(fitnessSourceModule.sso.fitnessSourceSelectedDate) ? 
                            fitnessSourceModule.deletePrevSourceData() : null;
                            cordovaModule.isPedometerAvailable(function(isAvail) {
                            if (isAvail) {
                                // Stop the pedometer count
                                isPedoStarted = localStorage.getItem("isPedoStarted")
                                if(device.platform!="iOS"){
                                    if (isPedoStarted == "true") {
                                            cordovaModule.stopPedometer();
                                    }
                                }
                                //start  the pedometer
                                /* Google fit logic change Move the startPedometer to course recording*/
                                cordovaModule.startPedometer(fitnessSourceModule.syncStepwithDB);
                                //Get the pedometer count value 
                            } else {
                                navigator.notification.alert(pedometerErrorMsg,null,"");
                            }
                            });
                            fitnessSourceModule.syncStepwithDB();
                           //var fitnessSetInterval =  setInterval(fitnessSourceModule.syncStepwithDB, getSourceInterval)
                            //commonModule.storage.setItem("fitnessSetInterval",fitnessSetInterval);
                         }
                         else
                         {
                                // TODO : if google fit is not available or user cancelled the popUp
                         }
                        });
                    }, function(){
                     navigator.notification.alert(googleFitUnavailable,null,"");   
                    })                    
                }                    
                break;
                case stepSource[1]://fitbit
                    if(cordovaModule.connection()){
                        var fbConfig = {
                            client_id: "227KST",//227P3D
                            scope: "activity",
                            redirect_uri: "http://localhost",
                            expires_in: "2592000"
                        };
                        var url = "https://www.fitbit.com/oauth2/authorize?response_type=token&client_id=" + fbConfig.client_id + "&redirect_uri=" + fbConfig.redirect_uri + "&scope=" + fbConfig.scope + "&expires_in=" + fbConfig.expires_in;
                        if(fitnessSourceModule.sso.fitbitToken === null || fitnessSourceModule.sso.fitbitToken === undefined){
                            fitnessSourceModule.getAuthToken(url).then(function(code){
                                if(code !== null){
                                   var isPrevSourceGooglefit;
                                   if(fitnessSourceModule.sso.prevSource === stepSource[0])
                                   {
                                       isPrevSourceGooglefit = false;
                                   }
                                    commonModule.updateSSO({fitbitToken : code,
                                    goofitEnabled: isPrevSourceGooglefit
                                    });
                                    if (fitnessSourceModule.sso.misfitLastHourSteps !== undefined) commonModule.updateSSO({misfitLastHourSteps : 0});
                                    //clearInterval(fitnessSourceModule.sourceInterval);
                                    //fitnessSourceModule.sourceInterval = setInterval(fitnessSourceModule.getDataFromFitbit, getSourceInterval);
                                    mljDate.getMLJIsToday(fitnessSourceModule.sso.fitnessSourceSelectedDate) ? 
                                    fitnessSourceModule.deletePrevSourceData().then(function(){
                                        fitnessSourceModule.getDataFromFitbit(fitnessSourceModule.sso.lastUploadSyncToSFDC);
                                    }) : fitnessSourceModule.getDataFromFitbit(fitnessSourceModule.sso.lastUploadSyncToSFDC);
                                }
                                else {
                                    navigator.notification.alert(usernotregisteredwithfitbit,null,"");
                                }
                            },function(error){
                                delete fitnessSourceModule.sso.source;
                               var isPrevSourceGooglefit;
                               if(fitnessSourceModule.sso.prevSource === stepSource[0])
                               {
                                   isPrevSourceGooglefit = true;
                               }
                                commonModule.updateSSO({
                                    source: fitnessSourceModule.sso.prevSource,
                                    fitnessSourceSelectedDate: fitnessSourceModule.sso.prevSource!==undefined?new Date():undefined,
                                    fitnessSourceSelectedCount: 0,
                                    goofitEnabled: isPrevSourceGooglefit
                                });
                                synchronisation.updateStepCountinDashboard();
                            });
                        }
                        else{
                            fitnessSourceModule.getDataFromFitbit(fitnessSourceModule.sso.lastUploadSyncToSFDC);
                        }
                    }
                break;
                case stepSource[2]://misfit
                    if(cordovaModule.connection()){
                        misfitHandler = new this.misfit({
                            clientId: '18zpqmDM4EmGHiZG',//XsweTZwRNWxYMDR8
                            clientSecret: 'Ku7xlEVTQBC7u40fJqPQdTSsCHNCHaZA',//4Ww8yG1MDjGMNgJeL8mS0jOfFfKwXaiv
                            redirectUri: 'http://localhost'
                        });
                        if(fitnessSourceModule.sso.misfitToken === null || fitnessSourceModule.sso.misfitToken === undefined){
                            fitnessSourceModule.setMisfitToken().then(function(result){
                                if(result.code !== null && result.code.length > 0 && result.status){
                                    misfitHandler.getAccessToken(result.code[1], function(err, token){
                                        var isPrevSourceGooglefit;
                                        if(fitnessSourceModule.sso.prevSource === stepSource[0])
                                         {
                                             isPrevSourceGooglefit = false;
                                         }
                                        
                                         commonModule.updateSSO({
                                            misfitToken : token,
                                            goofitEnabled: isPrevSourceGooglefit
                                         });
                                        if (fitnessSourceModule.sso.fitbitLastHourSteps !== undefined) commonModule.updateSSO({fitbitLastHourSteps : 0});
                                        //clearInterval(fitnessSourceModule.sourceInterval);
                                        //fitnessSourceModule.sourceInterval = setInterval(fitnessSourceModule.getDataFromMisfit, getSourceInterval);
                                        mljDate.getMLJIsToday(fitnessSourceModule.sso.fitnessSourceSelectedDate) ? 
                                        fitnessSourceModule.deletePrevSourceData().then(function(){
                                            fitnessSourceModule.getDataFromMisfit(fitnessSourceModule.sso.lastUploadSyncToSFDC, new Date());
                                        }) : fitnessSourceModule.getDataFromMisfit(fitnessSourceModule.sso.lastUploadSyncToSFDC, new Date());
                                    });
                                }
                                else {
                                    navigator.notification.alert(usernotregisteredwithmisfit,null,"");
                                }
                            },function(error){
                                delete fitnessSourceModule.sso.source;
                                var isPrevSourceGooglefit;
                                if(fitnessSourceModule.sso.prevSource === stepSource[0])
                                {
                                  isPrevSourceGooglefit = true;
                                }
                                commonModule.updateSSO({
                                    source: fitnessSourceModule.sso.prevSource,
                                    fitnessSourceSelectedDate: fitnessSourceModule.sso.prevSource!==undefined ? new Date():undefined,
                                    fitnessSourceSelectedCount: 0,
                                    goofitEnabled: isPrevSourceGooglefit
                                });
                                synchronisation.updateStepCountinDashboard();
                            });
                        }
                        else{
                            fitnessSourceModule.getDataFromMisfit(fitnessSourceModule.sso.lastUploadSyncToSFDC, new Date());
                        }
                    }
                break;
                case stepSource[4]://donotset
                	navigator.notification.alert(usernotmappedwithfitnesssource,null,"");
                	break;
                default:
                    navigator.notification.alert(usernotmappedwithfitnesssource,null,"");
                	break;
            }
       console.timeEnd('Fitnessinitialize');
		},
        syncStepwithDB:function(){
        synchronisation.sso = JSON.parse(commonModule.storage.getItem("sso"));
        if(synchronisation.sso.source != stepSource[0] ){
            console.log("google interval stopped");
            return false;
       
        }
        console.log("******************sync with google/healthkit steps*********************" + new Date());
            // if(device.platform == "iOS")
            // {
                //$("#loading-indicator").show();
				$("#sync-loader").show();
                synchronisation.updateDBforLastsevenDays().then(function(){
                    synchronisation.updateStepCountinDashboard().then(function(result){
                        if(result) synchronisation.uploadStepDatatoSFDC(fitnessSourceModule.sso.lastUploadSyncToSFDC, new Date());
                    });
                });
            //     synchronisation.updateStepCountinDashboard().then(function(result){
            //     if(result) synchronisation.uploadStepDatatoSFDC(sso.lastUploadSyncToSFDC, new Date()); 
            // });
                 $("#loading-indicator").hide();
            //} 
            
        },
        setMisfitToken : function(){
            var deferred = $.Deferred();
            if(misfitHandler !== null && misfitHandler !== undefined){
                var authorizeUrl = misfitHandler.getAuthorizeUrl();                        
                fitnessSourceModule.getAuthToken(authorizeUrl).then(function(code){
                    deferred.resolve({status: true, code: code});
                }, function(code){
                    if(code === null) deferred.reject({status: false, code: null});
                });
            }
            else deferred.reject({status: false, code: null});
            return deferred.promise();
        },
        getDataFromFitbit : function(startDate){
		console.time('getDataFromFitbit');
		   synchronisation.sso = JSON.parse(commonModule.storage.getItem("sso"));
		   if(synchronisation.sso.source != stepSource[1] ){
				console.log("fitbit interval stopped");
				return false;
		   }
		   console.log("**********************sync with fitbit steps*******************" + new Date());
            var deferred = $.Deferred();
            alternateStartDate = (synchronisation.sso.lastUploadSyncToSFDC !== "undefined")?mljDate.getMLJCurrentDate(synchronisation.sso.lastUploadSyncToSFDC) : mljDate.getMLJCurrentDate();
            startDate = (typeof startDate !== "undefined") ? mljDate.getMLJCurrentDate(startDate) : alternateStartDate;
            var limit = mljDate.getMLJDiffDatetime(startDate);
			var lastSyncDate = startDate,count=0;
            for(var i = 5; i <= limit; i++){
                startDate = fitnessSourceModule.timeLimit(startDate);
            }
			
            limit = mljDate.getMLJDiffDatetime(startDate);
            for(var i = 0; i <= limit && limit <= 5; i++){
                fitnessSourceModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
                fitnessSourceModule.invocationData.url = fitbitapi + '/activities/date/' + startDate + '.json';
                fitnessSourceModule.invocationData.type = "GET";
                fitnessSourceModule.invocationData.startDate = startDate;
				if(limit > 0){
					var request  = clientService.fitbitSyncRequest(fitnessSourceModule.invocationData);
				}
				else{
					var request  = clientService.fitbitRequest(fitnessSourceModule.invocationData);
				}
                request.done(function(response) {
                    if(response !== null && response !== undefined && response.summary !== undefined){
                        var fitbitObj = {
                            startDate: this.startDate,
                            endDate: this.startDate,
                            steps: response.summary.steps,
							lastSyncDate : lastSyncDate
                        };
						if(mljDate.getMLJIsToday(this.startDate)){
						commonModule.updateSSO({
                                dashboardStepCount: response.summary.steps
                            });
						}else{
						if(response.summary.steps >0)fitnessSourceModule.PrevDateSummaryStep = response.summary.steps;
						}
						
                        fitnessSourceModule.getTransactionData(fitbitObj).then(function(result){
                            if(result.status && limit === count){
								 synchronisation.updateStepCountinDashboard()
                                        synchronisation.uploadStepDatatoSFDC(fitnessSourceModule.sso.lastUploadSyncToSFDC, new Date());
                                        deferred.resolve(true);
                                    
                            }
							else{
								count++;
							}
                        },function(error){
						$("#sync-loader").hide();
                            deferred.reject(false);
                        });
						
                    }
                    else {
					$("#sync-loader").hide();
                       deferred.reject(false);
                    }
                });
                request.fail(function (error) {
                    error.responseText = (error.responseText==='' && error.responseText === undefined) ? 'unknown error' : error.responseText;
                    console.log(error.responseText);
                    deferred.reject(false);
                });
                startDate = mljDate.getMLJIsToday(startDate) ? startDate : fitnessSourceModule.timeLimit(startDate);
            }
			console.timeEnd('getDataFromFitbit');
            return deferred.promise();
        },
        getDataFromMisfit : function(startDate, endDate){
      
       synchronisation.sso = JSON.parse(commonModule.storage.getItem("sso"));
       if(synchronisation.sso.source != stepSource[2] ){
            console.log("mifit interval stopped");
            return false;
       
       }
	    console.log("*******************sync with misfit steps********************"+ new Date());
            var deferred = $.Deferred();
            fitnessSourceModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
			
			alternateStartDate = (synchronisation.sso.lastUploadSyncToSFDC !== "undefined")?mljDate.getMLJCurrentDate(synchronisation.sso.lastUploadSyncToSFDC) : mljDate.getMLJCurrentDate();
            startDate = (typeof startDate !== "undefined") ? mljDate.getMLJCurrentDate(startDate) : alternateStartDate;
            endDate = (typeof endDate !== "undefined") ? mljDate.getMLJCurrentDate(endDate) : mljDate.getMLJCurrentDate();
            var limit = mljDate.getMLJDiffDatetime(startDate);
			var lastSyncDate = startDate,count=0;
            for(var i = 5; i <= limit; i++){
                startDate = fitnessSourceModule.timeLimit(startDate);
            }
            if(misfitHandler !== null && misfitHandler !== undefined && fitnessSourceModule.sso.misfitToken !== undefined){
                misfitHandler.getSummary(fitnessSourceModule.sso.misfitToken, startDate, endDate, {detail: true}, function(err, summary){
                    if(summary !== null && summary !== undefined && summary.summary.length > 0){
					var data = summary.summary,endDt,startDt,newObj=[],k=0;
					startDt = new Date(startDate)
					endDt = new Date(endDate);
					var days = mljDate.getMLJDiffDatetime(startDate);
					for(var i=0;i<=days;i++){
						startDt = new Date(startDate);
						startDt.setDate(startDt.getDate() + i);
					  if(typeof data[k] != "undefined" && data[k].date == mljDate.getMLJCurrentDate(startDt)){
						newObj[i]={
						"date":data[k].date,
						"steps":data[k].steps
						}
						k++;
					  }
					  else{
					  newObj[i]={
						"date":mljDate.getMLJCurrentDate(startDt),
						"steps":0
						}
					  }
					}
                        $.each(newObj, function(index, obj) {
                            var misfitObj = {
                                startDate: obj.date,
                                endDate: obj.date,
                                steps: obj.steps,//summary.summary[0].steps
								lastSyncDate : lastSyncDate
                            };
							if(mljDate.getMLJIsToday(obj.date)){
							commonModule.updateSSO({
                                dashboardStepCount: obj.steps
                            });
							
							}else{
						if(obj.steps >0)fitnessSourceModule.PrevDateSummaryStep = obj.steps;
						}
						
							fitnessSourceModule.getTransactionData(misfitObj).then(function(result){
                                if(result.status && days === count){
                                    synchronisation.updateStepCountinDashboard()
                                        synchronisation.uploadStepDatatoSFDC(fitnessSourceModule.sso.lastUploadSyncToSFDC, new Date());
                                        deferred.resolve(true);
                                         
                                }
								else{
									count++;
								}
                            },function(error){
							$("#sync-loader").hide();
                                deferred.reject(false);
                            });
						
						
                            
                        });
                    }
                    else{
					$("#sync-loader").hide();
                        deferred.reject(false);
                    }
                });
            }
            else{
			$("#sync-loader").hide();
                deferred.reject(false);
            }
            return deferred.promise();
        },
        timeLimit: function(startDate){
            startDate = mljDate.getMLJNextDate(startDate);
            return mljDate.getMLJCurrentDate(startDate);
        },
        getTransactionData : function(datasource){
		console.time('getTransactionData');
            var deferred = $.Deferred(), transactionData = {}, lastHourSyncSteps, stepCount = 0, lastHourSyncProperty;
            var campaignObj = commonModule.activeCampaignDetails.getItem;
            transactionData.campaignId = (campaignObj === null || campaignObj === undefined) ? null : campaignObj.campaignId;
            transactionData.achievedStepCount = datasource.steps;
            lastHourSyncSteps = fitnessSourceModule.sso.source === 'misfit' ? fitnessSourceModule.sso.misfitLastHourSteps : fitnessSourceModule.sso.fitbitLastHourSteps;
            //lastHourSyncProperty = fitnessSourceModule.sso.source === 'misfit' ? 'misfitLastHourSteps' : 'fitbitLastHourSteps';
            //if(lastHourSyncSteps !== undefined && parseInt(datasource.steps) >= parseInt(lastHourSyncSteps) && mljDate.getMLJIsToday(datasource.startDate)){
			if(lastHourSyncSteps !== undefined && parseInt(datasource.steps) >= parseInt(lastHourSyncSteps) && datasource.startDate == datasource.lastSyncDate){
                stepCount = parseInt(datasource.steps) - parseInt(lastHourSyncSteps);
                transactionData.achievedStepCount = stepCount.toString();
            }
			transactionData.source = fitnessSourceModule.sso.source;
            if(mljDate.getMLJIsToday(datasource.startDate)){
			  transactionData.lastUpdatedTime = mljDate.getMLJCurrentDatetime();
			}
			else{
			datasource.endDate = datasource.endDate+" 23:59:59"
			transactionData.lastUpdatedTime = mljDate.getMLJCurrentDatetime(datasource.endDate);
			}
			//transactionData.lastUpdatedTime = mljDate.getMLJCurrentDatetime(datasource.endDate);
            transactionData.startDateTime = mljDate.getMLJLastHourDatetime(datasource.startDate);
			if(transactionData.achievedStepCount > 0){
            fitnessSourceModule.setTransactionData(transactionData).then(function(result){
                if(result) {
					if(mljDate.getMLJIsToday(datasource.startDate)){
								if(fitnessSourceModule.sso.source === 'misfit')commonModule.updateSSO({misfitLastHourSteps : datasource.steps});
								if(fitnessSourceModule.sso.source === 'fitbit')commonModule.updateSSO({fitbitLastHourSteps : datasource.steps});
                            }
						//synchronisation.updateStepCountinDashboard().then(function(result){
                        //if(result) synchronisation.uploadStepDatatoSFDC(fitnessSourceModule.sso.lastUploadSyncToSFDC, new Date());
                        deferred.resolve({status:true,startDate:datasource.startDate,stepCount:datasource.steps});
                    //});                    
                }
                else deferred.reject(false);
            });
			}
			else{
				if(mljDate.getMLJIsToday(datasource.startDate) && transactionData.achievedStepCount==0 && datasource.steps ==0){
				if(fitnessSourceModule.sso.source === 'misfit')commonModule.updateSSO({misfitLastHourSteps : fitnessSourceModule.PrevDateSummaryStep});
				if(fitnessSourceModule.sso.source === 'fitbit')commonModule.updateSSO({fitbitLastHourSteps : fitnessSourceModule.PrevDateSummaryStep});
				}
				//synchronisation.updateStepCountinDashboard().then(function(result){
				deferred.resolve({status:true});
				//}); 
			}
			console.timeEnd('getTransactionData');
            return deferred.promise();
        },
        setTransactionData : function(transactionData) {
		console.time('setTransactionData');
            var deferred = $.Deferred();
            var registry = mljdbproc.colDefinition(mljdbConstantModule.tables[1].columns);
            var insertQ = 'INSERT INTO ' + mljdbConstantModule.tables[1].name + ' (' + (registry.columnNameColl.join(',')) + ') VALUES (' + (registry.columnValColl.join(',')) + ')';
            registry.columnVal = [{}];
            registry.columnVal[0] = mljdbproc.mljColMapper(mljObjectModel.campaignTransaction, transactionData);
            var invocationData = {
                tablename: mljdbConstantModule.tables[1].name,
                seed: registry.columnVal[0],
                query: insertQ
            };
            $.when(mljdbproc.mljSetDataInDB(invocationData)).then(function(result) {
                if (!result) {
                    //call common error module
                    deferred.reject(false);
                }
                else deferred.resolve(true);
            });
			console.timeEnd('setTransactionData');
            return deferred.promise();
        },
        getAuthToken : function(authorizeUrl){
            var deferred = $.Deferred(), code = null, authError = null;
            if(authorizeUrl !== null && authorizeUrl !== undefined){
                var authWindow = window.open(authorizeUrl, '_blank', 'location=no,toolbar=yes,closebuttoncaption= 完了');
                $(authWindow).on('loadstart', function(e) {
                    var url = e.originalEvent.url;
                    if(fitnessSourceModule.sso.source !== stepSource[1]) code = /\?code=(.+)$/.exec(url);
                    else if(fitnessSourceModule.sso.source === stepSource[1] && url !== null && url.indexOf('access_token') > 0){
                        code = url.split('&').filter(function(el) { if(el.match('token_type') !== null) return true; })[0].split('=')[1] + ' ' +
                               url.split('&').filter(function(el) { if(el.match('access_token') !== null) return true; })[0].split('=')[1];
                    }
                    authError = /\?error=(.+)$/.exec(url);
                    if (code || authError) {
                        authWindow.close();
                        deferred.resolve(code);
                    }                    
                });
                $(authWindow).on('exit', function(result){
                    if(code === null) deferred.reject(code);
                });
            }
            else deferred.reject(code);
            return deferred.promise();
        },
        deletePrevSourceData : function(){
            var deferred = $.Deferred();
            fitnessSourceModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            var today = mljDate.getMLJCurrentDate(fitnessSourceModule.sso.fitnessSourceSelectedDate);
            var deleteQ = 'DELETE FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime LIKE "' + today + '%"';
            $.when(mljdbproc.query(deleteQ)).then(function(result){
                if(result) {
                    commonModule.updateSSO({
						lastUploadSyncToSFDC:new Date(),
                        todayUploadSyncData : 0
                    });
                    deferred.resolve(true);
                }
                else deferred.reject(false);
            },function(error){
                deferred.reject(false);
            });
            return deferred.promise();
        },
        checkAchievedStepCount : function(){
            var deferred = $.Deferred();
            fitnessSourceModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            var data = { "email": fitnessSourceModule.sso.email }, invocationData;
            fitnessSourceModule.invocationData.url = "/services/apexrest/MainDashBoard";
            fitnessSourceModule.invocationData.type = "POST";
            fitnessSourceModule.invocationData.data = data;
            synchronisation.updateOAuthToken().then(function(result){
                var request = clientService.cleintRequest(fitnessSourceModule.invocationData);
                request.done(function(response) {
                    if (response.Status.toLowerCase() === "success" && response.Data.length > 0) {
                        commonModule.activeCampaignDetails.getItem.achievedStepCount = parseInt(response.Data[0].totalStepCount);
                        invocationData = {
                            columns : {
                                achievedStepCount : response.Data[0].totalStepCount,
                                prizesToBeClaimed : response.Data[0].totalPrizesPending,
                                lastUpdatedTime : new Date($.now())
                            },
                            campaignId : commonModule.activeCampaignDetails.getItem.campaignId,
                            tablename : mljdbConstantModule.tables[0].name
                        };
                        $.when(mljdbproc.updateSpecificColumnsToDB(invocationData)).then(function(result){
                            if(result){
                                mljdbproc.activateCampaign();
                                deferred.resolve(true);
                            }
                        });
                    }
                    else deferred.reject(false); 
                });
                request.fail(function (error) {
                    if(error !== undefined && error !== null){
                        error.responseText = (error.responseText === '' || error.responseText === null || error.responseText === undefined) ? navigator.notification.alert(unknownerror,null,"") : navigator.notification.alert(error.responseText,null,"");
                        deferred.reject(false);
                    }
                });
            });
            return deferred.promise();
        },
        updateCompleteBadge: function(){
            var activePage = $.mobile.activePage.attr('id');
            fitnessSourceModule.checkAchievedStepCount().then(function(result){
                var activeCampaignDetails = commonModule.activeCampaignDetails.getItem;
                if((activeCampaignDetails !== null || activeCampaignDetails !== undefined) && activePage === 'dashboard-page'){
                    var achievedStepCount = commonModule.activeCampaignDetails.getItem.achievedStepCount === null ? 0: commonModule.activeCampaignDetails.getItem.achievedStepCount;
                    if(parseInt(achievedStepCount) >= parseInt(commonModule.activeCampaignDetails.getItem.campaignTarget)){
                        navigator.notification.alert(congratulations,null,"");
                    }
                }
            }); 
        }
    };
    return fitnessSourceModule;
});