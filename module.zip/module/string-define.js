/** 
    @path: js/module/string-define.js 
    @atuthor: Cognizant 
    @lastModifiedby: muthukumar 
    @Desc: variable declaration 
**/
var NOTIFICATION_CONFIRMATION_EXITCOURSE_TITLE = "";
var NOTIFICATION_CONFIRMATION_EXIT_COURSE_MESSAGE = "登録せずに閉じますか？";
var NOTIFICATION_CONFIRMATION_BUTTON1 = "キャンセル";
var NOTIFICATION_CONFIRMATION_BUTTON2 = "閉じる";
var NetworkConnectionError = "接続にエラーが発生しました。"; //"Network error"; 
var doNotSet_Jp = "今は設定しない";
var doNotSet_en = "Do not set now";
var NetworkConnection = "インターネットに接続できません"; //"No internet connection available!"; 
var googlefitNotAvailable = "この携帯にはグーグルフィットがありません。MisFit または FitBitを利用してください";
var stepSource = ['googlefit', 'fitbit', 'misfit', 'healthkit', 'donotset'];
var usernotmappedwithfitnesssource = "設定から、デバイス・アプリ設定をしてください"; //"Please update the fitness source on the settings"; 
var usernotregisteredwithmisfit = "Please register with misfit";
var usernotregisteredwithfitbit = "Please register with fitbit";
var campaignExpired = "登録しようとしているキャンペーンは終了しています"; //"Campaign you trying to register is already expired!"; 
var oAuthInterval = 1000 * 60 * 60 * 5;
var dashboardInterval = 1000 * 60 * 60;
var getSourceInterval = 1000 * 60 * 5;
var timer;
var networkconnectivity = 10000;
var uploadSyncInterval = 1000 * 60 * 1;

var appResumed = false;
var appLastSyncTime = new Date();
var oAuthIntervalTime = new Date().getTime()-1000*60*70;
var manualSyncNosource = "設定から、デバイス・アプリ設定をしてください";

var weekday = ["日", "月", "火", "水", "木", "金", "土"]; //["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"]; 
var alldatawilllost = "新しい機種で登録してよろしいですか。確認を押すとすべてのデータが失われます"; //"Are you sure to register with the new device? Please press confirm to loose all data."; 

/* UAT url 
var SFDCURL = 'https://test.salesforce.com/services/oauth2/token'; 
var enCryptData = "U2FsdGVkX1+nwq9uX7cmiaD2DB5oMO7q47DEsmpQ0RNlHkL+rrZPcnP3lHZ00tvIp2p3bSP9PjKPKCNXsY5YOng9qWqldlYjYvKJH1ZgHRZothqvSiCQu62+nJ3YVSJbEzhALFob9+plyqLT76tvfCTt6JC1XYKZmq60hj1l7H9k/D1EDRhBWlF+hqjnLvb9OB6zTUjXYberd7PD7MiLAK3QWQnZ6PnqzIzWRsCI225y7HQzCFuR2jy0qdqzswCNU5fFUzoPaCSwM40UDVMzw4RtaA1SwbOGaq4UBeZJOnvyBfudsKEP9mHMBHkpUB2t";*/

/* Prod Url */ 
var SFDCURL = 'https://login.Salesforce.com/services/oauth2/token'; 
// Prod encrypt
var enCryptData = "U2FsdGVkX1+WoQiwlOGpLrouVr5rI/YXWULFOo3HygS3FiUqVRUyaOF1udsL8RWBBwCevobv2jUgm8DkyIYKjv2biPbddY/8QFKDVQJuMKgOeKbgabEowpbRNM1jQo28LQORsC0WHWFHtn8g1dV8H+US5Ym8v5bG0noGaTqRR7SXvh5mTpsfxAyDrQjAF/glfGRbEBoxOeilEGWjacp+QXt9hGFVMx1rCldtIhI8ZfWH+CEfwJv3Dxw11KNxLAudrC9TJZd8Fhf+xXLMzaqLpNDOd06U4k3GzPTMvH1icP0="; 

var batchNoMapper = {
    "SFDC-User-Batch-1": "1:0:0",
    "SFDC-User-Batch-2": "1:05:0",
    "SFDC-User-Batch-3": "1:10:0",
    "SFDC-User-Batch-4": "1:15:0"
};
var fitbitapi = 'https://api.fitbit.com/1/user/-';
var checkConnectivity = "インターネットに接続できません";
var cameraMaxImageErrorMsg = "写真は９枚まで使用できます"; // Cannot take more than 9 pictures
var courseTitleErrorMsg = "コース名を入力してくさだい";
var courseDescErrorMsg = "コメントを入力してください";
var pedometerErrorMsg = "この携帯には歩数計機能がありません";
var registeredCourseErrorMsg = "エラーが発生したためしばらくたってから登録してください";
var viewregisteredCourseErrorMsg = "エラーが発生したためしばらくたってから登録してください";
var walkMapDestinationError = "到着地点を入力してください"; //"Please enter the destination place"; 
var walkMapSourceError = "出発地点を入力してください"; //"Please enter the source place"; 
var unknownerror = "サーバーに接続できません。しばらくたってからやり直してください";
var achievedDailytarget = "おめでとうございます！今日の目標歩数を達成しました";
var notificationError = "Notifications cannot be added because app doesn't have permission";

var nicknamenotempty = "ニックネームを入力してください"; //"Nick name should not be empty"; 
var entertargetsteps = "目標歩数を入力してください"; //"Enter the target steps"; 
var emailmandatory = "Emailは必須項目です"; //Email is mandatory 
var invalidemail = "無効なEmailです"; //Invalid Email 
var nicknameMandatory = "ニックネームは必須項目です"; //Nick name is mandatory 
var selectGender = "性別を選択してください"; //Select the gender 
var yobMandatory = "生年は必須項目です"; //Year of Birth is mandatory 
var invalidYob = "無効な生年です"; //Invalid Year of Birth 
var pleaseAgreeTerms = "利用規約に承諾してください"; //Please agree to the Terms and Conditions 
var notauthorizedwithGooglefit = "グーグルフィットを使用する権限がありません"; //You are not authorized with googlefit 
var googlefitActivated = "グーグルフィットが使用できます"; //GoogleFit is activated 
var gpsAccuracyError = "GPSをオンにすると位置情報がより正確になります。このまま継続しますか？";
var gpsErrorTitle = ""; //remove if possible this one. 
var continueTxt = "継続";
var cancelTxt = "キャンセル";
var sourcechangewarning = "デバイス変更をすると、変更当日のデータに新しいデバイスのデータが上書きされます。\r\nまた、デバイスの変更は1日1回のみ可能です。変更してもよいですか？";
var sourcechangenotpermit = "デバイスの変更は1日1回のみです。\r\n明日以降、ご変更ください";
var existinguser = "Login Successful for existing user";
var existinguserdifferentdeviceId = "Login Successful and device Id updated for existing user";
var wellnesTabLink = "http://wellnesslab.manulife.co.jp/walk/";
var alreadyacquired = "くつの寄付が完了しています！";
var alreadyacquirederror = "Already claimed campaign prize";
var alreadyacompaniedsource = "すでに連携しています";
var geolocationPermissionError = "位置情報をオンにしてください";
var facebookToastMsg = "登録したコースの情報をペーストしてください";
var courseRecordingStart = "出発地";
var PedometerPermissionError = "「設定」で、「モーションとフィットネス」を有効にしてください";
var congratulations = "おめでとうございます！靴の寄付に必要な歩数を達成しました";
var noshoesavailable = "シューズドネーション（くつの寄付）へのご参加ありがとうございます。皆さまのおかげで目標の2000足に達しました。引き続きManulife WALKでウォーキングをお楽しみください。";
var skippedRegistration = "New user Registration complete";
var skipperuserCampaignMsg = "シューズドネーション（くつの寄付）に参加するには、登録が必要となります";
var errorInAccessingLoction = "“位置情報にアクセスできません";
//var errorInAccessingLoction =  "Error in accessing the location. Please try again later"
var LocationServicesDisabled = "";//"位置情報サービスが無効になっています";
//var LocationServicesDisabled = "Location Services Disabled";

var showLocationServiceConfirm = "私のコースとお散歩マップを記録するためには位置情報サービスを有効にしてください";
//var showLocationServiceConfirm= "Location Service Disabled","Please enable location services for recording a course and walkmap."

//var motionFitnessDisabled=  "Motion & Fitness services Disabled"
var motionFitnessDisabled = "";

var pedoerror = "歩数計がエラーです。もう一度試してください";
//var pedoerror = "Error pedometer. Please try again later";

//var fbError = "Error occured, Please install facebook if not installed or try again later";
var fbError = "Facebookをインストールし、後でもう一度やり直してください";

//var twitterError = ""Error occured, Please install twitter if not installed or try again later"";
var twitterError = "Twitterをインストールし、後でもう一度やり直してください";

var insertError = "後でもう一度やり直してください";
//var insertError = "Error occured, Please try again later"

//var googleFitUnavailable = "GoogleFit/Healthkit is not available is your device";
var googleFitUnavailable = "この携帯にはグーグルフィットがありません";

//var noResultfound = "No results found";
var noResultfound = "検索結果が見つかりません";

//var geoCoderFailed = "Geocoder failed "
var geoCoderFailed = "ロケーションエラー";

//var walkmapDirectionFail = "Directions request failed"
var walkmapDirectionFail = "コースが見つかりません";

// var useralreadyExists= ""
var useralreadyExists = "アプリを再ダウンロードし、登録済みの方法を再度選択してください";