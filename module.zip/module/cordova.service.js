define(["cordova", "jquery","./mljDate.js"], function (cordova,$,mljDate) {
    console.log("Loading cordova.service.js");
    var cordovaModule = {
        initialize: function () {

            // This check helps to detect whether we are on a dev web
            // server, or the actual device.
            if (cordova && cordova.version) {
                console.log("Cordova version:" + cordova.version);
                //cordovaModule.getDeviceID();
            } else {
                console.log("Not running in a Cordova environment");
            }
        },
        getDeviceID: function () {
            /*var storeddeviceID = window.localStorage.getItem("deviceUUID");
            var deviceId = document.getElementById("deviceid");
            deviceId.innerHTML = 'Device Name: ' + device.name + '<br />' +
                'Device Cordova: ' + device.cordova + '<br />' +
                'Device Platform: ' + device.platform + '<br />' +
                'Device UUID: ' + device.uuid + '<br />' +
                'Device Version: ' + device.version + '<br />';
            if (!storeddeviceID) {
                window.localStorage.setItem("deviceUUID", device.uuid);
            }*/
        },
        isLocationEnabled:function(){
            if (this.isMobileDevice() === true ){
                cordova.plugins.diagnostic.isLocationEnabled(function(enabled){
                    if(!enabled){
                        cordovaModule.showLocationServiceConfirm(showLocationServiceConfirm);
                    } else { 
                        console.log("locationEnabled");
                    }
                }, function(error){
                    navigator.notification.alert("Error in accessing the location. Please try again later",null,"");
                });
            }
        },
        getCurrentLocation: function(callBack){           
                    var options={ maximumAge: 3000, timeout: 5000, enableHighAccuracy: true };
                    navigator.geolocation.getCurrentPosition(function(position){                   
                            return callBack(position);
                    },function(err){
                        console.log(err);
                     if(err.code ==1){
                        navigator.notification.alert(geolocationPermissionError, function(){
                            $.mobile.pageContainer.pagecontainer('change', '../dashboard.html', {
                              reverse: false,
                              changeHash: false
                            });
                            $("#loading-indicator").hide();
                        }, LocationServicesDisabled, "OK");
                     }
                     if(err.code ==2)
                     {
                     //navigator.notification.alert("Unable to get gps service, Please try again later");
                     navigator.notification.alert(geolocationPermissionError, function(){
                            $.mobile.pageContainer.pagecontainer('change', '../dashboard.html', {
                              reverse: false,
                              changeHash: false
                            });
                            $("#loading-indicator").hide();
                        }, LocationServicesDisabled, "OK");
                     }
                     if(err.code ==3)
                     {
                    // navigator.notification.alert("Unable to get gps service, Please try again later");
                     navigator.notification.alert(geolocationPermissionError, function(){
                            $.mobile.pageContainer.pagecontainer('change', '../dashboard.html', {
                              reverse: false,
                              changeHash: false
                            });
                            $("#loading-indicator").hide();
                        }, LocationServicesDisabled, "OK");
                     } 
                         
                    },
                    options);
        },

        showLocationServiceConfirm:function(msg) {
            if (this.isMobileDevice() === true ){
                navigator.notification.confirm(
                    msg,
                    cordovaModule.successLocationConfirm,
                    "",
                    'Enable,'
                );  
            } 
        },
        successLocationConfirm:function (selection){
            if (selection == 1) {
                cordova.plugins.diagnostic.switchToLocationSettings();
            } else {
                cordovaModule.getCurrentLocation();
            }
        },

        watchPosition:function(callback){
         var self = this;
         var options={ maximumAge: 3000, timeout: 5000, enableHighAccuracy: true };
            window.locationWatchId = navigator.geolocation.watchPosition(
                function(data){
                    callback(data)
                },
              function(err){console.log(err)},
              options);
        },
        storeGoogle:function(courseStartDateTime,courseStopDateTime,steps,callback){
            self =this;
            navigator.health.store({
            startDate: courseStartDateTime, // course start 
            endDate:  courseStopDateTime, // end Date
            dataType: 'steps',
            value: steps,
            source: 'manulifewalk'}, callback, self.errorCallbak)
        },
        isPedometerAvailable:function(callback){          
            if(device.platform == "iOS")
            {
                pedometer.isStepCountingAvailable(function(){
                    //success callback
                    console.log("pedo available")
                    callback(true);
                }, function(){
                    //error callback
                    console.log("pedometer not avai")
                   cordovaModule.errorCallbak("Please try again later")
                });
            }  
            else
            {
                stepcounter.deviceCanCountSteps(function(){
                    console.log("pedo available")
                    callback(true);
                   }, function(){
                    console.log("pedometer not avai")
                   cordovaModule.errorCallbak("Please try again later");
                });    
            }
            
        },
        isBackgroundServiceEnabled:function(callback){
            callback(cordova.plugins.backgroundMode.isEnabled());
        },
        errorCallbak:function(msg){
            navigator.notification.alert(msg,null,"");
            $("#loading-indicator").hide();
        },
        startPedometer:function(callback){
            var startingOffset = 0;
            if(device.platform == "iOS")
            {
                pedometer.startPedometerUpdates(function(data){
                                       //alert(JSON.stringify(data));
                        localStorage.setItem("steps",data.numberOfSteps);
                        localStorage.setItem("isPedoStarted","true");
                        localStorage.setItem("getStepCount",data.numberOfSteps);
                        localStorage.setItem("courseStartTime",Date.now())
                        //alert("getStepCount = "+data.numberOfSteps);
                        $("#course-start  #courseSteps").text(data.numberOfSteps);
                        $("#course-start  #courseKm").text((data.numberOfSteps/1320).toFixed(2));
                       
                }, self.errorCallbak);
            }
            else
            {
                
                stepcounter.start(startingOffset, 
                    function(steps){
                        //localStorage.setItem("steps",steps); 
                       //  this.courseStartDateTime= new Date();    
                        localStorage.setItem("isPedoStarted","true");
                        callback();
                    }, 
                    function(data){
                        navigator.notification.alert("start failed "+JSON.stringify(data),null,"");
                        $("#loading-indicator").hide();
                });    
            }
            
        },
        isGoogleFitAvail:function(callback){
            var  self= this; 
            navigator.health.isAvailable(callback, self.errorCallbak)
        },
        requestAuthorization:function(callback){
             var  self= this;   
             if(self.connection())
             {
                navigator.health.requestAuthorization(["steps"], callback, self.errorCallbak)    
             }
             else
             {
                //self.errorCallbak("Network issue");
				$("#sync-loader").hide();
                $("#loading-indicator").hide();
             }            
        },
        connection:function(){
            if (this.isMobileDevice() === true ){
                var networkState = navigator.connection.type;
                var states = {};
                states[Connection.NONE] = 'no network';
                    if(states[networkState] == 'no network'){
                        return false;
                    }
                    return true;
                } else {
                    return true;
            }
        },
        /*---------------------Check device type-----------------------*/
        isMobileDevice:function() {
            if(navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) ||
              navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) ||
              navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) ||
              navigator.userAgent.match(/Windows Phone/i)){
               return true;
            } else {
               return false;
            }
            return false;
        },
        stopPedometer:function(){
            if(device.platform == "iOS")
            {
                pedometer.stopPedometerUpdates(
                    function(data){
                        // success callback
                        //alert("stopped "+JSON.stringify(data));
                        localStorage.setItem("courseStopTime",Date.now());
                    }, 
                    function(data){
                        //error callback
                        navigator.notification.alert("stop failed "+JSON.stringify(data),null,"");
                 });
            }
            else
            {
                  //var startingOffset = 0;
                 stepcounter.stop( 
                    function(data){
                        //alert("stopped "+JSON.stringify(data)); 
                        localStorage.setItem("isPedoStarted","false");
                    }, 
                    function(data){
                        navigator.notification.alert("stop failed "+JSON.stringify(data),null,"");
                        $("#loading-indicator").hide();
                 });   
            }
             
        },
        getStepHistory:function(callback){
                stepcounter.getHistory(callback, self.errorCallbak);
        },
        getTodayStepCount:function(callback){        
            var self = this;
            if(device.platform=="iOS")
            {
                var today = new Date();
                today.setHours(0,1,0);
                var todayStartTime = today.getTime();
                var now  =  Date.now();
              
                navigator.health.queryAggregated({
                startDate: today, //
                endDate: new Date(), //
                dataType: 'steps'},
                function(data){
                     callback(data.value);
                }, self.errorCallbak)
               
            }
            else
            {
                stepcounter.getTodayStepCount(callback, self.errorCallbak);
            }
        },
        getLastSevenDaysData : function(callback){
		 $("#loading-indicator").show();
		var sso = JSON.parse(localStorage.getItem("sso"));
				if(device.platform !== "iOS"){
					  cordovaModule.requestAuthorization(function(data){
						if(data === "OK"){  
							var startDate;
							//var sso = JSON.parse(localStorage.getItem("sso"));
							var fitnessSourceSelectedDate = sso.fitnessSourceSelectedDate;
							var lastfitnessSourceSelectedDate = new Date(fitnessSourceSelectedDate).getTime();
							var last7day = new Date().getTime() - 7 * 24 * 60 * 60 * 1000;
							var appInstalledDay  = new Date(localStorage.getItem("appRegisteredDate")).getTime();
					   
							if(last7day > lastfitnessSourceSelectedDate)
							{
								startDate =  new Date(last7day);
							}
							else
							{
								startDate = new Date(lastfitnessSourceSelectedDate);
							}
							var stDate = mljDate.getMLJCurrentDatetime(startDate);
							var endDate = new Date().getTime(),endDt,startDt, obj=[],count=0;
							//var days = Math.ceil((endDate - startDate.getTime())/24/3600/1000);
							var days = mljDate.getMLJDiffDatetime(stDate);
							for(var i=0;i <= days; i++){ 
								   startDt = new Date(startDate);
								   startDt.setDate(startDt.getDate() + i)
								   startDt.setHours(0);
								   startDt.setMinutes(0);
								   startDt.setSeconds(0);
								   endDt = new Date(startDt);
								   endDt.setHours(23);
								   endDt.setMinutes(59);
								   endDt.setSeconds(59);
									navigator.health.queryAggregated({
									startDate: startDt, // 7 days ago or app installed date
									endDate: endDt, // now
									dataType: 'steps'
								}, function(data){
									if(count == days)
									{
									obj[count] = data;
									callback(obj)
									}else{
									obj[count] = data;
									count++;
									}	
								}, function(err){
								console.log(err);
								
								if(sso.source=="googlefit"){
									cordovaModule.requestAuthorization();
								}
								
									
								});
							}
		
		 		 }
		 }); 
		
		
		}
		
else{			
			//console.log(new Date(new Date().getTime() - 7 * 24 * 60 * 60 * 1000))      
            var startDate;
            //var sso = JSON.parse(localStorage.getItem("sso"));      
       /*Instead of last seven days, we are getting the data from the date of fitnessSource changed*/
            var fitnessSourceSelectedDate = sso.fitnessSourceSelectedDate;
            var lastfitnessSourceSelectedDate = new Date(fitnessSourceSelectedDate).getTime();
            var last7day = new Date().getTime() - 7 * 24 * 60 * 60 * 1000;
            var appInstalledDay  = new Date(localStorage.getItem("appRegisteredDate")).getTime();       
       // if(last7day > appInstalledDay)
       // {
       //     startDate =  new Date(lastfitnessSourceSelectedDate);
       // }
       // else
       // {
       //     startDate = new Date(lastfitnessSourceSelectedDate);
       // }
            startDate =  new Date(lastfitnessSourceSelectedDate);
            startDate.setHours(0)
            startDate.setMinutes(0)
            startDate.setSeconds(0)
       
            navigator.health.query({
                startDate: startDate, // 7 days ago or app installed date
                endDate: new Date(), // now
                dataType: 'steps'
            }, function(data){callback(data)}, self.errorCallbak);			
			}   
       
		
		 },
		getPedometerSteps:function(callback){
            if(device.platform == "iOS")
            {
                localStorage.setItem("stop", Date.now());
                var startDate = localStorage.getItem("start");
                var endDate = localStorage.getItem("stop");
                var options = {
                    "startDate": new Date(JSON.parse(startDate)),
                    "endDate": new Date(JSON.parse(endDate))
                };
       
                pedometer.queryData(function(data){
                        var storedStepcount = localStorage.getItem("getStepCount");
                            storedStepcount = (storedStepcount == null) ? 0 : storedStepcount;
                        var updatedStepCount = parseInt(storedStepcount); 
                        if(updatedStepCount< data.numberOfSteps)
                        {
                           localStorage.setItem("getStepCount",data.numberOfSteps);
                           $("#course-start  #courseSteps").text(data.numberOfSteps);
                           $("#course-start  #courseKm").text((data.numberOfSteps/1320).toFixed(2));
                        }
                        else
                        {
                            callback(updatedStepCount);
                              $("#loading-indicator").hide();
                        }
                    },
                    function(data){
                       // navigator.notification.alert("error in pedometer");
                        if(data == "The operation couldn’t be completed. (CMErrorDomain error 105.)") {
                            navigator.notification.alert(PedometerPermissionError, function(){
                             $.mobile.pageContainer.pagecontainer('change', '../dashboard.html', {
                                  reverse: false,
                                  changeHash: false
                                  });
                             $("#loading-indicator").hide();
                             },motionFitnessDisabled, "OK");
                            }
                            else
                            {

                            }
                          $("#loading-indicator").hide();
                    },
                options);
            }
            else
            {
             stepcounter.getStepCount( 
                function(data){ 
                        var storedStepcount = localStorage.getItem("getStepCount");
                        storedStepcount = (storedStepcount == null) ? 0 : storedStepcount;
                        var updatedStepCount = parseInt(storedStepcount); 
                        if(updatedStepCount< data)
                        {
                           localStorage.setItem("getStepCount",data);
                           $("#course-start  #courseSteps").text(data);
                           $("#course-start  #courseKm").text((data/1320).toFixed(2));
                           callback(data);
                        }
                        else
                        {
                            callback(updatedStepCount);
                              $("#loading-indicator").hide();
                        }
                      callback(data)
                }, 
                function(data){
                    navigator.notification.alert(pedoerror,null,"");
                    $("#loading-indicator").hide();
            });   
            }
             
        },
        socialShare:function(socailNetwork,params, callback){
            var imageUrl = null;
            if(params[1] =="donation")
            {
                if(socailNetwork == "facebook")
                {
                     var message ="Manulife WALK \r\n\r\n"+ params[0];
                     var imageUrl = "www/img/shoe_pairs.jpg";
                     facebookToastMsg = "";
                }
                else
                {
                    var message = params[0]+"\r\n\r\n";
                    var imageUrl = "www/img/shoe_pairs.jpg";
                }
            }
            else
            {
                if(device.platform != "iOS")
                {
                    //imageUrl = "file://"+localStorage.getItem("screenshotFilePath");       
                }
                else
                {
                    //imageUrl = localStorage.getItem("screenshotFilePath"); 
                }
                if(localStorage.getItem("mapPage") =="walkmap")
                {
                   // imageUrl = null; 
                }
				wellnesTabLink = localStorage.getItem("fbpathLink");
				//wellnesTabLink = "<a href='"+wellnesTabLink+"'>My Route</a>";
                if(socailNetwork == "facebook"){
					//wellnesTabLink = localStorage.getItem("fbpathLink");
                    var message ="マニュライフ生命" +' \r\n '+"[Manulife WALK] \r\n"+  params[0]+' \r\n\r\n '+params[1]+' \r\n\r\n '+params[2];
                }                     
                if(socailNetwork == "twitter"){
					imageUrl = localStorage.getItem("fbpathLink");
					wellnesTabLink = null;
                    var message ="マニュライフ生命" +' \r\n ' +"[Manulife WALK] \r\n"+params[0]+' \r\n\r\n '+params[1] + " \r\n を登録しました。";
					}
            }
              
            if(socailNetwork == "facebook")
            {
                 window.plugins.socialsharing.shareViaFacebookWithPasteMessageHint(
                    message, 
                    imageUrl /* img */,
                    wellnesTabLink /* url */, 
                    facebookToastMsg, 
                    callback('share ok'), 
                    function(errormsg){
                        navigator.notification.alert(fbError,null,"");
                        $("#loading-indicator").hide();
                 });    
            }
             if(socailNetwork == "twitter")
             { 
                window.plugins.socialsharing.shareViaTwitter(
                     message, 
                    imageUrl /* img */, 
                    wellnesTabLink/* url */, 
                    callback("shared twitter"),
                    function(err){
                         navigator.notification.alert(twitterError,null,"");
                         $("#loading-indicator").hide();
                    });
             }
            
        },
        CaptureImage:function(callback){
          navigator.screenshot.save(function(error,res){
              if(error){
                console.error(error);
              }else{
                console.log('ok',res.filePath);
                localStorage.setItem("screenshotFilePath",res.filePath);
                callback();
              }
            },'jpg',50);
        },
        cameraGetPicture:function(callback){ 
           var DestinationType = Camera.DestinationType.FILE_URI;
            if(device.platform == "iOS")
            {
                 var DestinationType = Camera.DestinationType.NATIVE_URI;
            }
            var cameraOptions ={
                destinationType: DestinationType,
                sourceType: Camera.PictureSourceType.CAMERA,
                saveToPhotoAlbum:true,
                correctOrientation: true             
            }
            navigator.camera.getPicture(function(data){
                callback(data);
            }, 
            function(err){
                callback(err);
                $("#loading-indicator").hide();
            }, cameraOptions);
        },
		galleryGetPicture:function(callback){
            var cameraOptions ={
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
				quality: 50,
				encodingType:Camera.EncodingType.JPEG,
				mediaType: Camera.MediaType.PICTURE,
				allowEdit: true,
                correctOrientation: true
            }
            navigator.camera.getPicture(function(data){
                callback(data);
            }, 
            function(err){
                callback(err);
                $("#loading-indicator").hide();
            }, cameraOptions);
        },
		localNotification:function(obj){
			cordova.plugins.notification.local.hasPermission(function(granted){
				  if(granted == true)
				  {
               		  cordova.plugins.notification.local.schedule(
                  		obj,
                        function(data){
                            console.log(JSON.stringify(data))
            			});
				  }
				  else
				  {
					cordova.plugins.notification.local.registerPermission(function(granted) {
						if(granted == true)
						{
						  cordova.plugins.notification.local.schedule(obj);
						}
						else
						{
                          console.log("app does not have permission")
						  navigator.notification.alert("Reminder cannot be added because app doesn't have permission",null,"");
						}
					});
				  }
			})
		}
    };
    return cordovaModule;
});