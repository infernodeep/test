define(["jquery","fix-orientation"], function($,fixOrientation) {
    console.log("Loading common.js");

    // Contains methods to import resources bundled by Webpack
    var webpackUtil = {
        initStyles: function() {

            // This file is directly merged into the bundle file by Webpack.
            require("jquery.mobile.css");
            //require( "ratchet.css" );
            require("swiper.css");
            require("webfonts.css");
            require("app.css");
            require("registration.css");
            require("dashboard.css");
            require("pedometer.css");
            require("walkmap.css");
            require("donation.css");
            require("course.css");
            require("settings.css");
        }
    };

    // Contains methods to initialize jQuery resources
    var jqueryUtil = {
        initAjaxDefaults: function() {

        },
        initAjaxLoadingIndicator: function() {

            // Show a loading indicator when the ajax call starts and hide it automatically when it completes. This is done using global ajax event handlers (see http://api.jquery.com/category/ajax/global-ajax-event-handlers/) as decribed here: http://stackoverflow.com/a/5600281/3872997.
            $(document).ajaxStart(function() {
                $("#loading-indicator").show();
            }).ajaxStop(function() {
                $("#loading-indicator").hide();
            });

            // Initially, the loading indicator will be hidden
            $("#loading-indicator").hide();
            $("#sync-loader").hide();
        }
    };
    var storage = {
        getItem: function(id) {
            return localStorage.getItem(id);
        },
        setItem: function(id, value) {
            localStorage.setItem(id, value);
        }
    };
    var newCampaignDetails = {
        item : null,
        get getItem() { 
            return this.item;
        },
        set setItem(value) {
            this.item = value
        }
    };
    var activeCampaignDetails = {
        item : null,
        get getItem() { 
            return this.item;
        },
        set setItem(value) {
            this.item = value
        }
    };
    var userInfo = {
        item : null,
        get getItem() { 
            return this.item;
        },
        set setItem(value) {
            this.item = value
        }
    };
    // Contains methods shared across modules
    var commonModule = {
        initialize: function() {
            webpackUtil.initStyles();
            jqueryUtil.initAjaxLoadingIndicator();
        },
        mljDBInit: function(){
            var db = window.openDatabase("MLJDB", "1.0", "Manulife Walk Japan", 200000);
            //var db = window.sqlitePlugin.openDatabase({name: "MLJDB", location: 1});
            return db;
        },
        checkNetworkConnection: function(){
            if(!navigator.onLine) {
                commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
            }
        },
        toaster: function(options) {
            if ($("#toaster-container").length) {
                commonModule.toasterClose();
            }
            $("body").prepend("<div id='toaster-container'><div id='toaster-center'><div id='toaster-message-container'>" + options.text + "</div><div id='toaster-button-container'></div></div></div><div id='toaster-modal'></div>");
            switch (options.type) {
                case "error":
                    $("#toaster-container").addClass("toaster-error");
                    break;
                case "success":
                    $("#toaster-container").addClass("toaster-success");
                    break;
                case "warning":
                    $("#toaster-container").addClass("toaster-warning");
                    break;
                case "info":
                    $("#toaster-container").addClass("toaster-info");
                    break;
                default:
                    $("#toaster-container").addClass("toaster-error");
            }
            $("#toaster-container").fadeIn("slow");
            if (options.modal) {
                $("#toaster-modal").show();
            }
            $("#toaster-container, #toaster-modal").click(function() {
                commonModule.toasterClose();
            });
            if (options.timeout || options.timeout === false) {
                if (options.timeout !== false) {
                    toasterTimeout = setTimeout(commonModule.toasterClose, options.timeout);
                    console.log(options.timeout);
                }
            } else {
                toasterTimeout = setTimeout(commonModule.toasterClose, 3000);
            }
        },
        toasterClose: function() {
            clearTimeout(toasterTimeout);
            $("#toaster-container:first").fadeOut("slow", function() {
                $(this).remove();
            });
            $("#toaster-modal:first").fadeOut("slow", function() {
                $(this).remove();
            });
        },
        storage: storage,
        newCampaignDetails: newCampaignDetails,
        activeCampaignDetails: activeCampaignDetails,
        userInfo: userInfo,
        updateSSO: function(obj){
            sso = JSON.parse(commonModule.storage.getItem("sso")) || {};
            $.each(obj, function(key, value) {
                sso[key] = value;
            });
            commonModule.storage.setItem("sso", JSON.stringify(sso));
        },
		 updateLocalstorage: function(obj,item){
            objItem = JSON.parse(commonModule.storage.getItem(item)) || {};
            $.each(obj, function(key, value) {
                objItem[key] = value;
            });
            commonModule.storage.setItem(item, JSON.stringify(objItem));
        },
        getImgURI: function(image) {
            var c = document.createElement('CANVAS');
            var img = image;
            var a = c.toDataURL("image/png");
            console.log(a);
            return a;
        },
        formatDate:function(date){
            var week=["SUN","MON","TUE","WED","THU","FRI","SAT"];
            var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

            if (month.length < 2) month = '0' + month;
            if (day.length < 2) day = '0' + day;
            var formattedDate = [year, month, day].join('.');
             var  weekDay = d.getDay();

        return formattedDate + "("+week[weekDay]+")";
        },
		/*Text will shrinks on the number charatcters */
        shrinkText: function() {
            $.fn.shrinkText = function(txt) {
                var $_me = this;
				if($_me.length === 0) return false;
				$_me.removeAttr("style");
                var $_parent = $_me.parent();
				var int_parent_width = $_parent.width()-$_parent.position().left;
				var count = (typeof a_string === 'string')?txt.toString():txt;
				var commatxt;
                if(txt != undefined){
				commatxt = $_me.numberWithCommas(count);
				}else
				{
				commatxt = "";
				}
                $_me.html(commatxt);
                var int_my_width = $_me.width();
                if (int_my_width > int_parent_width) {

                    rl_ratio = int_parent_width / int_my_width;

                    var int_my_fontSize = $_me.css("font-size").replace(/[^-\d\.]/g, '');
                    //var int_my_fontSize = 50;

                    int_my_fontSize = Math.floor(int_my_fontSize * rl_ratio);
                    int_my_fontSize = (int_my_fontSize / $(window).width()) * 100

                    $_me.css("font-size", int_my_fontSize + "vw");

                } else {
                    $_me.removeAttr("style");
                }
				
            };
            $.fn.numberWithCommas = function(x) {
                return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }

        },

        sortJson:function(arr,prop, asc) {
            data = arr.recommendedCourses;
           return data = data.sort(function(a, b) {
                if(device.platform == "iOS")
                { 
                    return a[prop] < b[prop] ? -1 : a[prop] > b[prop] ? 1 : 0;
                }
                else
                {
                    if (asc) return (a[prop] > b[prop]);
                    else return (b[prop] > a[prop]);
                }
            }); 
        },
		urlShortener:function(strURL){
		var deferred = $.Deferred();
		var urlShortenerKey = "AIzaSyDxLyENNte3zhgb8HrzHEr9ajeqr0-NNiE";
		  var request = $.ajax({
                url: 'https://www.googleapis.com/urlshortener/v1/url?shortUrl=http://goo.gl/fbsS&key='+urlShortenerKey,
                type: 'POST',
				contentType: 'application/json; charset=utf-8',
				data: '{ longUrl: "' + strURL +'"}',
				dataType: 'json'
            });
            request.done(function(response) {
			deferred.resolve(response.id);
			 });
            request.fail(function(jqXHR, textStatus) {
                console.log(textStatus);
				 deferred.reject(null);
            });
			return deferred.promise();
		
		}

		
		
    };
    return commonModule;
});